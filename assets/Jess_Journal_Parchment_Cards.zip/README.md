# Jess’s Birthday Adventure: Parchment Cards

This pack includes four independent WebP UI assets, with PNG masters.

**Small location card:** `parchment_small_card.webp`

**Infinitely extendable detail card:** `parchment_top.webp`, `parchment_middle.webp`, `parchment_bottom.webp`

The top and bottom are fixed caps, and the center is a vertically repeating 256 px tile. The center tile's first and last RGBA rows are identical, as are the adjoining rows on the caps. Do **not** scale the middle vertically to fill a long card: repeat it at its natural aspect ratio. Three joins were tested with exact 0-difference RGBA boundaries.

After uploading this ZIP to the GitHub feature branch as `assets/Jess_Journal_Parchment_Cards.zip`, the Pages workflow will place the four WebP assets in `dist/assets/parchment/`. This deploys the **images only**. Styling the application's location and chapter cards is a separate step.

## Basic CSS assembly idea

```html
<div class="parchment-detail-card">
  <img class="parchment-top" src="assets/parchment/parchment_top.webp" alt="">
  <div class="parchment-middle"> ... your existing HTML content ... </div>
  <img class="parchment-bottom" src="assets/parchment/parchment_bottom.webp" alt="">
</div>
```

```css
.parchment-detail-card { display:flex; flex-direction:column; width:100%; }
.parchment-detail-card img { width:100%; display:block; height:auto; pointer-events:none; }
.parchment-middle {
  background-image:url('assets/parchment/parchment_middle.webp');
  background-size:100% auto;
  background-repeat:repeat-y;
  padding: 0 10%;
}
```

For pixel-exact joins at arbitrary content height, use the provided `browser_demo.html` with its ResizeObserver technique to make the center section contain an exact whole number of repeats. Keep functional buttons and labels as HTML.
