Realistic satchel jar sprites

ruby_sprite.png: Ruby Mae filled jar, full resolution, transparent
empty_sprite.png: empty cork jar, full resolution, transparent
ruby_site.webp and empty_site.webp: small optimized website versions

Only Ruby Mae and the empty jar are included. The other eight filled jar images have not been generated yet.
