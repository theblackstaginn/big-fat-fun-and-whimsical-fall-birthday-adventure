# Jess's Satchel: 3D Oddities Jars
Nine separate, unlabeled glTF 2.0 binary jar models.

Each model has a hand-blown glass body with inner wall and visible foot, a natural cork stopper, antique brass collars, and an individual small brass charm. The jar interiors are empty and contain no text, labels, or baked-in painting. During app integration, locked jars can stay empty and the original location paintings from assets/scenes/ can be placed inside only when unlocked.

Every model is built with its base at Y=0 and is about 1.32 units tall. The jars are separate GLB files so each can be placed and rotated as a true 3D object on the lazy Susan.

Preview: open preview.html in a browser with internet access. If local-file access blocks GLB loading, run python3 -m http.server 8000 in this folder and open http://localhost:8000/preview.html.
