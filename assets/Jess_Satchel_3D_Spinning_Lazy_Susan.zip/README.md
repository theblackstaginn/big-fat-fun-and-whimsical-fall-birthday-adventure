# The Satchel: Oddities Turntable

A genuinely three-dimensional, slowly rotating wooden lazy Susan for Jess's birthday-adventure Satchel. This is an original procedurally authored 3D asset, not a static image or a set of jars baked into a picture.

## Files

- `oddities_lazy_susan_spinning.glb`: 3D model with embedded 12-second rotation animation, glTF 2.0 / Y-up.
- `oddities_lazy_susan_static.glb`: same turntable with no animation, for JavaScript-controlled swipe-to-spin.
- `lazy_susan_spinning_preview.gif`: short looping rotating visual proof, not the interactive game asset.
- `lazy_susan_3d_preview.png`, `lazy_susan_side_view.png`: static visual previews.
- `lazy_susan_isolated.webp` and `.png`: transparent-background 2D fallback for layered UI.
- `mesh_manifest.json`: nine jar seat locations and rotating parent node information.
- `viewer.html`: touch-friendly 3D preview using Google's model-viewer library (requires an internet connection for the library and a local web server or static website for the GLB).
- `build_lazy_susan.py`: editable procedural 3D source code (Python, numpy, Pillow, trimesh).
- `walnut_top.jpg` and `walnut_edge.jpg`: editable texture sources; textures are **also embedded in the GLB**.

## Construction

- Rich aged walnut tabletop, simulated wood grain, copper/bronze double edge, leaf and star detailing, center crest.
- Nine unobstructed circular positions for nine separately rendered glass jars.
- A fixed wooden-and-bronze pedestal plus independent node `Turntable_Rotating`.
- GLB animation `One Gentle Full Turn - 12 Seconds` spins the platter **clockwise** about its vertical Y axis, one turn per 12 seconds. The model's stand does not spin.
- Optimized down to 11 material geometry groups to reduce mobile draw calls.

## Using the jar images

There are **no location paintings or jars inside this asset**. Keep the approved nine individual transparent jar PNG/WebP overlays, and the approved original location WebPs, separate. In a Three.js or similar 3D scene, attach jar image planes or billboards to the rotating node so they follow the platform. Use the coordinates in `mesh_manifest.json`, expressed in the local `Turntable_Rotating` coordinate space. The platform is intended for nine jars with unique oddities; locked jars stay empty and only acquired locations show their approved images.

To preview on a PC from this folder, run `python -m http.server 8080` and visit `http://localhost:8080/viewer.html`. On mobile, put `viewer.html` and the GLB together in a static hosting directory, then open its URL. The viewer loads a third-party model-viewer module; the GLB itself has no runtime dependency.

## Deployment status

**No live birthday-adventure website files were modified as part of this asset creation.** Integrate only after visual approval.
