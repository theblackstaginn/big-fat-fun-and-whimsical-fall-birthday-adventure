import os, math, struct, json, io, zipfile
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageEnhance
import trimesh
from trimesh.visual.material import PBRMaterial
from trimesh.visual.texture import TextureVisuals

ROOT = Path('/mnt/data/oddities_lazy_susan')
ROOT.mkdir(parents=True, exist_ok=True)
RNG = np.random.default_rng(13057)

# Rich, slightly plum-toned old walnut with actual grain and small pore patterns.
W=2048; H=2048
y,x=np.mgrid[:H,:W].astype(np.float32)
u=x/W; v=y/H
# A mostly horizontal board grain; slow x-dependent warping gives natural elongated growth curves.
warp = (0.007*np.sin(2*np.pi*(u*2.6+v*.38)) + .004*np.sin(2*np.pi*(u*4.5-v*.26))
        +.003*np.sin(2*np.pi*(u*11.4+v*.63))+.001*np.sin(2*np.pi*(u*27+v*.35)))
phase = v + warp
fine = np.sin(2*np.pi*(phase*126 + .25*np.sin(2*np.pi*u*6)))
medium = np.sin(2*np.pi*(phase*32 + .13*np.sin(2*np.pi*u*3.3)))
wide=np.sin(2*np.pi*(phase*8.1 + .08*np.sin(2*np.pi*u*1.7)))
noise = RNG.normal(0,1,(H,W)).astype(np.float32)
# Grain long, not dithered: smooth across x with high-frequency along y.
noise = .24*noise + .12*np.roll(noise,1,axis=1)+.12*np.roll(noise,-1,axis=1)
brightness = .49 + .11*wide+.060*medium+.027*fine+.025*noise
# worn rings near radial edge and subdued knots
rad = np.sqrt(((u-.5)/.5)**2+((v-.5)/.5)**2)
brightness = brightness - .11*np.clip((rad-.80)/.20,0,1)
# Overlay a few plank joins as exceptionally subtle dark hairlines.
for seam in [.348,.661]:
 brightness -= .06*np.exp(-((v-seam-.003*np.sin(u*8*np.pi))/.0017)**2)
base=np.array([68,38,34],dtype=np.float32)
light=np.array([165,107,69],dtype=np.float32)
tex=np.clip(base[None,None,:]+brightness[:,:,None]*(light-base)[None,None,:],0,255).astype('uint8')
img=Image.fromarray(tex,'RGB')
d=ImageDraw.Draw(img,'RGBA')
# Subtle dark, elongated knots (with faint nested ellipses), each aligned with grain.
for cx,cy,rx,ry in [(488,477,100,21),(1460,1480,132,24),(1580,460,110,18),(760,1640,90,20)]:
 for j in range(8):
  w=int(rx+j*6); h=int(ry+j*3)
  d.ellipse((cx-w,cy-h,cx+w,cy+h),outline=(25,9,8,14 if j>2 else 25),width=2)
 d.ellipse((cx-32,cy-6,cx+32,cy+6),fill=(21,9,9,35))
# Light wooden pore flecks, soft and very small
for _ in range(3300):
 cx=int(RNG.integers(0,W));cy=int(RNG.integers(0,H))
 length=int(RNG.integers(2,15))
 d.line((cx,cy,cx+length,cy),fill=(13,8,6,int(RNG.integers(8,27))),width=1)
img=img.filter(ImageFilter.GaussianBlur(.35))
img.save(ROOT/'walnut_top.jpg',quality=92,subsampling=0)

# Narrow side-grain texture stretches around the platter circumference.
SW,SH=2048,512
sy,sx=np.mgrid[:SH,:SW].astype(np.float32)
a=sx/SW; b=sy/SH
p = b+.012*np.sin(2*np.pi*(a*8+b*.3))+.006*np.sin(2*np.pi*(a*17-b*.4))
f = .5 + .15*np.sin(2*np.pi*p*44)+.11*np.sin(2*np.pi*p*105)+.08*np.sin(2*np.pi*p*9)
f += RNG.normal(0,.025,(SH,SW)).astype(np.float32)
side=np.clip(np.array([48,28,31])[None,None,:]+f[:,:,None]*np.array([100,55,33])[None,None,:],0,255).astype('uint8')
Image.fromarray(side).save(ROOT/'walnut_edge.jpg',quality=90)

WOOD = PBRMaterial(name='Hearth-aged figured walnut',baseColorTexture=img, metallicFactor=0.0,roughnessFactor=.67,baseColorFactor=(255,255,255,255))
SIDE = PBRMaterial(name='Carved walnut edge grain',baseColorTexture=Image.fromarray(side),metallicFactor=0.,roughnessFactor=.63,baseColorFactor=(255,255,255,255))
# Distinct PBR metals / enamel for old-world autumn magic.
BRONZE = PBRMaterial(name='Antique hammered copper',baseColorFactor=(172,105,62,255),metallicFactor=.80,roughnessFactor=.33)
GOLD = PBRMaterial(name='Burnished bronze leaf inlay',baseColorFactor=(217,160,88,255),metallicFactor=.77,roughnessFactor=.28)
DARK_BRONZE = PBRMaterial(name='Darkened patinated bronze',baseColorFactor=(94,56,49,255),metallicFactor=.65,roughnessFactor=.42)
PLUM = PBRMaterial(name='Enamel deep plum',baseColorFactor=(68,37,53,255),metallicFactor=.24,roughnessFactor=.38)
DARK_WOOD = PBRMaterial(name='Walnut end grain',baseColorFactor=(67,41,38,255),metallicFactor=0.0,roughnessFactor=.77)

scene=trimesh.Scene()
parent='Turntable_Rotating'
spinner_transform=np.eye(4); spinner_transform[1,3]=.30
scene.graph.update(frame_to=parent, frame_from='world',matrix=spinner_transform)
meshes=[]


def add(name, mesh, material, rotating=True):
    if mesh is None or len(mesh.faces)<1:return
    if not (hasattr(mesh.visual,'uv') and mesh.visual.uv is not None):
        mesh.visual=TextureVisuals(material=material)
    else:
        mesh.visual.material=material
    scene.add_geometry(mesh,geom_name=name,node_name=name,parent_node_name=parent if rotating else 'world')
    meshes.append((name,mesh,material,rotating))

def lathe(profile, n=240, material=None, side_uv=True, cap=False):
    verts=[]; uvs=[]; faces=[]
    for ir,(radius,hei) in enumerate(profile):
        for j in range(n+1):
            ang=2*math.pi*j/n
            verts.append((radius*math.cos(ang),hei,radius*math.sin(ang)))
            uvs.append((j/n,ir/max(1,len(profile)-1)))
    for ir in range(len(profile)-1):
        for j in range(n):
            i0=ir*(n+1)+j; i1=i0+n+1
            faces.extend(((i0,i1,i0+1),(i0+1,i1,i1+1)))
    out=trimesh.Trimesh(vertices=verts,faces=faces,process=False)
    out.visual=TextureVisuals(uv=np.array(uvs,dtype=np.float32),material=material)
    return out

def disc(radius,y,material,segments=320,rings=20,reverse=False,center=(0,0)):
    # UV planar wood; texture remains in object space, rotates together with platter.
    vv=[(center[0],y,center[1])]; uv=[(.5,.5)]
    for k in range(1,rings+1):
        rr=radius*k/rings
        for j in range(segments+1):
            theta=j/segments*math.tau
            px=center[0]+rr*math.cos(theta); pz=center[1]+rr*math.sin(theta)
            vv.append((px,y,pz));uv.append((.5+px/(2*3.1),.5+pz/(2*3.1)))
    ff=[]
    for j in range(segments):
        if reverse:ff.append((0,j+1,j+2))
        else:ff.append((0,j+2,j+1))
    for k in range(1,rings):
        a=1+(k-1)*(segments+1);b=1+k*(segments+1)
        for j in range(segments):
            t=[(a+j,b+j,a+j+1),(a+j+1,b+j,b+j+1)]
            if not reverse:t=[tuple(reversed(z)) for z in t]
            ff.extend(t)
    m=trimesh.Trimesh(vertices=vv,faces=ff,process=False)
    m.visual=TextureVisuals(uv=np.array(uv,dtype=np.float32),material=material)
    return m

def ring(radius, pipe, y, material=BRONZE, cx=0, cz=0, n=144, tube=9, name='ring',rotating=True):
    mesh=trimesh.creation.torus(major_radius=radius,minor_radius=pipe,major_sections=n,minor_sections=tube)
    mesh.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,(1,0,0)))
    mesh.apply_translation((cx,y,cz))
    add(name,mesh,material,rotating)

def cylindrical(radius,ymin,ymax,material,name,rotating=True,segments=144):
    mesh=trimesh.creation.cylinder(radius,height=ymax-ymin,sections=segments)
    mesh.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,(1,0,0)))
    mesh.apply_translation((0,(ymax+ymin)/2,0))
    add(name,mesh,material,rotating)

def small_sphere(radius,center,material,name,rotating=True):
    mesh=trimesh.creation.icosphere(subdivisions=1,radius=radius)
    mesh.apply_translation(center)
    add(name,mesh,material,rotating)

def line_mesh(points, radius, material, name):
    out=[]
    for a,b in zip(points[:-1],points[1:]):
        a=np.array(a);b=np.array(b); v=b-a;dist=np.linalg.norm(v)
        if dist<.0001:continue
        m=trimesh.creation.cylinder(radius=radius,height=dist,sections=7)
        T=trimesh.geometry.align_vectors([0,0,1],v/dist)
        if T is None:T=np.eye(4)
        m.apply_transform(T)
        m.apply_translation((a+b)/2)
        out.append(m)
    if out:add(name,trimesh.util.concatenate(out),material)

def leaf_mesh(cx,cz,angle,length,width,y,material,name):
    # Embossed tapered metallic leaf with raised midrib.
    ca,sa=math.cos(angle),math.sin(angle)
    def pt(l,w,yy):return (cx+ca*l-sa*w, yy, cz+sa*l+ca*w)
    verts=[pt(0,0,y),pt(length*.42,width*.48,y+.005),pt(length,0,y),pt(length*.42,-width*.48,y+.005),pt(length*.46,0,y+.022)]
    faces=[(0,1,4),(1,2,4),(2,3,4),(3,0,4)]
    add(name,trimesh.Trimesh(vertices=verts,faces=faces,process=False),material)

# Static dark foot / brass bearing, separate from rotating tabletop.
cylindrical(1.49,-.51,-.42,DARK_WOOD,'Fixed pedestal base',False)
ring(1.43,.035,-.466,DARK_BRONZE,name='Fixed pedestal bronze base rim',rotating=False)
ring(1.27,.018,-.421,GOLD,name='Fixed bottom halo',rotating=False)
cylindrical(.97,-.43,.10,DARK_WOOD,'Fixed bearing pedestal',False)
ring(.96,.035,.075,BRONZE,name='Fixed bearing metal',rotating=False)
ring(.94,.018,-.37,BRONZE,name='Fixed bearing lower line',rotating=False)
cylindrical(.74,.09,.26,DARK_BRONZE,'Fixed pivot bearing',False)

# Turntable: carved stepped profile and true textured wood top.
profile=[(0.,-.083),(2.80,-.083),(2.96,-.076),(3.05,-.048),(3.13,-.003),(3.17,.063),(3.175,.175),(3.14,.225),(3.07,.267),(3.00,.280)]
add('Thick hand-carved walnut turntable rim',lathe(profile,material=SIDE),SIDE)
add('Walnut platter top real-grain texture',disc(3.005,.280,WOOD),WOOD)
# Full hidden underside so underside looks finished from low angles.
add('Turntable underside walnut',disc(2.96,-.085,DARK_WOOD,segments=144,rings=1,reverse=True),DARK_WOOD)

# Radial turned lip and beveled copper filigree.
ring(3.116,.026,.235,BRONZE,name='Copper lip top')
ring(3.165,.021,.149,GOLD,name='Fine bright rim')
ring(3.171,.028,.088,BRONZE,name='Bronze braided outer rim')
ring(3.151,.010,-.008,DARK_BRONZE,name='Shadow bronze lower band')
ring(2.905,.012,.291,BRONZE,name='Inlaid circular vine border')
ring(2.835,.009,.292,GOLD,name='Inner copper hairline')
ring(1.365,.014,.292,DARK_BRONZE,name='Central walnut ornamental circle')

# Bronze scallops and copper nail heads in the border, with a subtle etched wreath.
for i in range(48):
    t=math.tau*i/48
    # Low rings on the vertical edge rather than intrusive top ornaments.
    x=3.177*math.cos(t); z=3.177*math.sin(t)
    small_sphere(.018,(x,.10,z),GOLD,f'Rim rivet {i+1:02d}')
for i in range(32):
    t=math.tau*i/32
    r=2.858
    cx=r*math.cos(t);cz=r*math.sin(t)
    tang=t+math.pi/2
    leaf_mesh(cx,cz,tang,.105,.048,.294,BRONZE,f'Botanical border leaf {i+1:02d}')

# Distinctive raised copper scrolling along the carved walnut fascia.
# These stay at the outermost side wall, leaving the jar pads unimpeded.
for i in range(24):
    center_t=(i+.5)*math.tau/24
    scroll=[]
    for j in range(15):
        local=(j/14-.5)*.18
        a=center_t+local
        y=.09+.035*math.sin((j/14)*math.tau)
        scroll.append((3.182*math.cos(a),y,3.182*math.sin(a)))
    line_mesh(scroll,.010,GOLD,f'Carved side scroll {i+1:02d}')
    # small bright copper berry at the heart of each scroll
    t=center_t
    small_sphere(.021,(3.192*math.cos(t),.102,3.192*math.sin(t)),BRONZE,f'Copper rosette {i+1:02d}')

# Three intentionally irregular botanical imprints help the motion read as a
# real rotating object even before the jars are placed on their seats.
for patch,(t,offset) in enumerate([(0.32,0.0),(2.73,.08),(4.45,-.04)]):
    r=2.69+offset
    cx=r*math.cos(t); cz=r*math.sin(t)
    for j in range(3):
        da=(j-1)*.11
        posangle=t+da
        px=cx+.075*math.cos(posangle)
        pz=cz+.075*math.sin(posangle)
        leaf_mesh(px,pz,posangle+math.pi/2,.14,.068,.296,BRONZE,
                  f'Asymmetrical falling leaf {patch+1}-{j+1}')

# Nine glass-jar places: bronze annular inlaid seats and engraved separators.
for i in range(9):
    t=i*math.tau/9-math.pi/2
    rr=2.08
    cx,cz=rr*math.cos(t),rr*math.sin(t)
    # Dark walnut circular knot, single metallic double ring, delicate retaining groove.
    # Keep the walnut texture visible through each jar seat.
    ring(.592,.014,.304,BRONZE,cx,cz,n=80,tube=7,name=f'Jar seat {i+1:02d} copper outline')
    ring(.538,.008,.305,GOLD,cx,cz,n=80,tube=6,name=f'Jar seat {i+1:02d} inner halo')
    # Three tiny cast-copper pinheads at edge, equidistant.
    for j in range(3):
        b=t+j*math.tau/3
        small_sphere(.016,(cx+.568*math.cos(b),.308,cz+.568*math.sin(b)),GOLD,f'Seat {i+1:02d} stud {j+1}')
    # Small radial tick at outer edge between sockets.
    mid=t+math.pi/9
    pts=[(2.70*math.cos(mid),.295,2.70*math.sin(mid)),(2.78*math.cos(mid),.295,2.78*math.sin(mid))]
    line_mesh(pts,.008,GOLD,f'Outer index notch {i+1:02d}')

# Enamel center medallion with gilded perimeter, thorn ornament, and moon / antlers crest.
cylindrical(.732,.291,.313,PLUM,'Deep plum central inset')
ring(.718,.040,.319,BRONZE,name='Central stag crest bright ring')
ring(.650,.012,.330,GOLD,name='Central stag crest inner filigree')
# Stylized antler lines on a flat medallion; designed to be legible on mobile.
Y=.333
# small stag face / rune
head=[(-.10,Y,-.23),(-.065,Y,-.02),(0,Y,.080),(.065,Y,-.02),(.10,Y,-.23),(0,Y,-.29),(-.10,Y,-.23)]
line_mesh(head,.021,GOLD,'Central stag head engraving')
for side in [-1,1]:
    # two main horns going outward, forked upwards on both sides
    main=[(side*.065,Y,.065),(side*.145,Y,.16),(side*.25,Y,.205),(side*.33,Y,.31),(side*.38,Y,.42)]
    line_mesh(main,.020,GOLD,('Left' if side<0 else 'Right')+' stag antler')
    branches=[([(side*.19,Y,.185),(side*.17,Y,.31),(side*.18,Y,.40)],'first'),
              ([(side*.29,Y,.26),(side*.34,Y,.37),(side*.32,Y,.48)],'second'),
              ([(side*.35,Y,.35),(side*.46,Y,.39),(side*.49,Y,.46)],'third')]
    for pts,nm in branches:line_mesh(pts,.012,BRONZE,f'{nm} {side} antler branch')
small_sphere(.03,(0,.356,.09),GOLD,'Stag crest sacred eye')
# Little crescent pair and sunbursts on rim of medallion.
for side in (-1,1):
    ta=np.linspace(-.83,.83,17)
    pts=[(side*.49+side*.038*np.cos(u*math.pi),.333,-.20+.18*np.sin(u*math.pi/2)) for u in ta]
    line_mesh(pts,.012,BRONZE,f'Moon crescent {side}')
for i in range(12):
    t=i*math.tau/12
    cx,cz=.595*math.cos(t),.595*math.sin(t)
    small_sphere(.011,(cx,.33,cz),GOLD,f'Medallion constellation dot {i:02d}')

# Merge geometry by material and animation parent for efficient mobile rendering.
# This reduces ~170 ornament fragments to a few draw calls while retaining all
# tangible 3D details; position and texture UV stay unchanged.
from collections import defaultdict
groups=defaultdict(list)
for name,mesh,mat,rotating in meshes:
    groups[(rotating,mat.name)].append((mesh,mat))
optimized=trimesh.Scene()
optimized.graph.update(frame_to=parent,frame_from='world',matrix=spinner_transform)
for (rotating,material_name),arr in groups.items():
    merged=trimesh.util.concatenate([q[0] for q in arr]) if len(arr)>1 else arr[0][0]
    mat=arr[0][1]
    if material_name not in ('Hearth-aged figured walnut','Carved walnut edge grain'):
        merged.visual=TextureVisuals(material=mat)
    optimized.add_geometry(merged,geom_name=('Rotating' if rotating else 'Fixed')+' '+material_name,
                           node_name=('Rotating' if rotating else 'Fixed')+' '+material_name,
                           parent_node_name=parent if rotating else 'world')
scene=optimized
print('Material groups after merge:',len(groups))

# Export static model and animated model (animation injected as glTF animation channel).
base=trimesh.exchange.gltf.export_glb(scene)
(ROOT/'oddities_lazy_susan_static.glb').write_bytes(base)

def inject_spin(glb, node_name='Turntable_Rotating'):
    magic,version,total=struct.unpack_from('<III',glb,0)
    assert magic==0x46546C67 and version==2
    off=12; chunks=[]
    while off<len(glb):
        length,ctype=struct.unpack_from('<II',glb,off);off+=8
        chunk=glb[off:off+length];off+=length
        chunks.append((ctype,chunk))
    parsed=json.loads(chunks[0][1].decode('utf-8').rstrip(' \t\0'))
    target=next((i for i,n in enumerate(parsed['nodes']) if n.get('name')==node_name),None)
    if target is None:
        # locate a node referenced by parent_node_name in exported scene graph
        raise RuntimeError('Spinner node not found. Nodes: '+str([(i,n.get('name')) for i,n in enumerate(parsed['nodes'][:15])]))
    # glTF 2.0 forbids animating a node that defines a matrix: convert it to TRS.
    animated_node=parsed['nodes'][target]
    if 'matrix' in animated_node:
        mat=np.asarray(animated_node.pop('matrix'),dtype=float).reshape(4,4,order='F')
        if not np.allclose(mat[:3,:3],np.eye(3),atol=1e-6):
            raise ValueError('Expected pure translation spinner node')
        animated_node['translation']=[float(v) for v in mat[:3,3]]
    animated_node['rotation']=[0.0,0.0,0.0,1.0]
    binidx=next(i for i,entry in enumerate(chunks) if entry[0]==0x004E4942)
    binary=bytearray(chunks[binidx][1])
    while len(binary)%4:binary.append(0)
    timeoffset=len(binary)
    times=np.array([0,2,4,6,8,10,12],dtype='<f4')
    binary.extend(times.tobytes())
    while len(binary)%4:binary.append(0)
    quat_offset=len(binary)
    angle=-2*np.pi*times/12
    quat=np.stack((np.zeros_like(times),np.sin(angle/2),np.zeros_like(times),np.cos(angle/2)),axis=-1).astype('<f4')
    binary.extend(quat.tobytes())
    while len(binary)%4:binary.append(0)
    buffers=parsed.setdefault('bufferViews',[]);accessors=parsed.setdefault('accessors',[])
    t_view=len(buffers); buffers.append({'buffer':0,'byteOffset':timeoffset,'byteLength':int(times.nbytes)})
    q_view=len(buffers); buffers.append({'buffer':0,'byteOffset':quat_offset,'byteLength':int(quat.nbytes)})
    t_acc=len(accessors);accessors.append({'bufferView':t_view,'componentType':5126,'count':len(times),'type':'SCALAR','min':[0.0],'max':[12.0]})
    q_acc=len(accessors);accessors.append({'bufferView':q_view,'componentType':5126,'count':len(times),'type':'VEC4'})
    parsed.setdefault('animations',[]).append({'name':'One Gentle Full Turn - 12 Seconds','samplers':[{'input':t_acc,'output':q_acc,'interpolation':'LINEAR'}], 'channels':[{'sampler':0,'target':{'node':target,'path':'rotation'}}]})
    parsed['buffers'][0]['byteLength']=len(binary)
    js=json.dumps(parsed,separators=(',',':')).encode('utf-8')
    while len(js)%4:js+=b' '
    out=b'glTF'+struct.pack('<II',2,12+8+len(js)+8+len(binary))+struct.pack('<II',len(js),0x4E4F534A)+js+struct.pack('<II',len(binary),0x004E4942)+binary
    return out,target,parsed
animated,node_id,jdoc=inject_spin(base)
(ROOT/'oddities_lazy_susan_spinning.glb').write_bytes(animated)
print('Spinner node:',node_id,'scene items:',len(meshes),'static bytes:',len(base),'animated bytes:',len(animated),'animations:',len(jdoc.get('animations',[])))
with (ROOT/'mesh_manifest.json').open('w') as h:
 json.dump({'format':'GLB 2.0','unit':'meters; stylized relative scale','orientation':'Y up','spinner_node':'Turntable_Rotating',
 'animations':['One Gentle Full Turn - 12 Seconds'],'stationary_pedestal':True,'jar_seats':9,
 'jar_positions':[{'index':i+1,'angle_radians':round(i*math.tau/9-math.pi/2,6),
 'x':round(2.08*math.cos(i*math.tau/9-math.pi/2),5),'y':.615,
 'z':round(2.08*math.sin(i*math.tau/9-math.pi/2),5)} for i in range(9)],
 'source':'original procedural art; separate model, no location images baked in'},h,indent=2)
